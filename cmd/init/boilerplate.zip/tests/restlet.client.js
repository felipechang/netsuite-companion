const {createLink} = require("nsrestlet");
require("dotenv").config();

module.exports = {
    createClient: () => {

        const settings = {
            accountId: process.env.NS_REALM,
            tokenKey: process.env.NS_TOKEN,
            tokenSecret: process.env.NS_TOKEN_SECRET,
            consumerKey: process.env.NS_CONSUMER_KEY,
            consumerSecret: process.env.NS_CONSUMER_SECRET_KEY
        };

        for (let key in settings) if (!settings[key]) throw new Error(`Missing environment variable: ${key}`);
        if (!process.env.NS_RESTLET_URI) throw new Error(`Missing environment variable: url`);

        return createLink(settings, {url: process.env.NS_RESTLET_URI});
    }
}