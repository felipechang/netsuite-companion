const {createClient} = require("./restlet.client");
require("dotenv").config();

describe('Testing via RESTlet', () => {

    // Extend test timeout
    jest.setTimeout(10 * 1000);

    it('should require an _action parameter', async () => {
        const client = createClient()
        const response = await client.get({test: "1234"});
        expect(response.errorCode).toBe("001");
        expect(response.taskId).toBe(-1);
        expect(response.error).toBe("parametro _action es requerido");
    });

    it('should require a _laika_id parameter', async () => {
        const client = createClient()
        const response = await client.get({_action: 'inventory_transfer'});
        expect(response.errorCode).toBe("001");
        expect(response.taskId).toBe(-1);
        expect(response.error).toBe("parametro _laika_id es requerido");
    });

    it('should require a _action parameter', async () => {
        const client = createClient()
        const response = await client.get({_laika_id: '123456'});
        expect(response.errorCode).toBe("001");
        expect(response.taskId).toBe(-1);
        expect(response.error).toBe("parametro _action es requerido");
    });

    it('should _action parameter should be valid', async () => {
        const client = createClient()
        const response = await client.get({_laika_id: '123456', _action: 'somerandom'});
        expect(response.errorCode).toBe("001");
        expect(response.taskId).toBe(-1);
        expect(response.error).toBe("parametro _action inválido");
    });
});